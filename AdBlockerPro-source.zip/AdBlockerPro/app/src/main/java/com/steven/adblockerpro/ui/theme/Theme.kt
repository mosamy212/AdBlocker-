package com.steven.adblockerpro.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColors = lightColorScheme(
    primary = ShieldGreenDark,
    background = BackgroundLight,
    surface = SurfaceLight,
    onBackground = TextPrimaryLight,
    onSurface = TextPrimaryLight,
    error = DangerRed
)

private val DarkColors = darkColorScheme(
    primary = ShieldGreen,
    background = BackgroundDark,
    surface = SurfaceDark,
    onBackground = TextPrimaryDark,
    onSurface = TextPrimaryDark,
    error = DangerRed
)

/**
 * Follows system light/dark ("night mode") automatically, and uses Android
 * 12+ dynamic color when available. Falls back to a fixed palette on
 * Android 9-11 where dynamic color doesn't exist.
 */
@Composable
fun AdBlockerProTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    themeOverride: String = "system", // "system" | "light" | "dark" — lets the user force it regardless of OS reporting
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val resolvedDark = when (themeOverride) {
        "light" -> false
        "dark" -> true
        else -> darkTheme
    }
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (resolvedDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        resolvedDark -> DarkColors
        else -> LightColors
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !resolvedDark
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
