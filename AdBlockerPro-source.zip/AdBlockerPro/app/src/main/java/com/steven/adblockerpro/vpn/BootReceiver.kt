package com.steven.adblockerpro.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import com.steven.adblockerpro.data.AppSettings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        CoroutineScope(Dispatchers.IO).launch {
            val settings = AppSettings(context)
            val autoStart = settings.autoStartEnabled.first()
            val wasOn = settings.wasProtectionOn.first()
            if (!autoStart || !wasOn) return@launch

            // VPN permission, once granted by the user, persists across reboots for this
            // app — VpnService.prepare() returns null when already approved, so this can
            // start silently with no new prompt.
            if (VpnService.prepare(context) != null) return@launch // permission was revoked somehow; can't silently start

            val presetId = settings.dnsPresetId.first()
            val serviceIntent = Intent(context, AdBlockVpnService::class.java)
            serviceIntent.putExtra(AdBlockVpnService.EXTRA_DNS_PRESET_ID, presetId)
            context.startForegroundService(serviceIntent)
        }
    }
}
