package com.steven.adblockerpro.vpn

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.steven.adblockerpro.MainActivity
import com.steven.adblockerpro.R
import com.steven.adblockerpro.data.AppSettings
import com.steven.adblockerpro.data.BlocklistManager
import com.steven.adblockerpro.data.BlocklistSources
import com.steven.adblockerpro.data.DnsPreset
import com.steven.adblockerpro.data.DnsPresets
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer

/**
 * Local, on-device ad blocker. No traffic is routed to any remote server
 * except plain DNS lookups (to whichever resolver the user picked) — this
 * is NOT a privacy VPN, it's a local filter that uses Android's VpnService
 * API as the only way to see per-app DNS traffic without root.
 */
class AdBlockVpnService : VpnService() {

    private var tunInterface: ParcelFileDescriptor? = null
    private var serviceJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)
    private val writeLock = Mutex() // guards concurrent writes to the TUN fd from parallel forward coroutines

    private var upstreamPrimary: InetAddress? = null
    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        private const val TAG = "AdBlockVpnService"
        const val CHANNEL_ID = "adblock_service"
        const val NOTIF_ID = 1
        const val ACTION_STOP = "com.steven.adblockerpro.STOP"
        const val EXTRA_DNS_PRESET_ID = "dns_preset_id"

        // Rough average size of an ad/tracker request that never gets to load (image,
        // script, tracking pixel, etc.) — used only to show an approximate "data saved"
        // figure. This is an estimate, not a measurement; the app has no way to know the
        // real size of a resource it prevented from ever being requested.
        private const val AVG_BLOCKED_REQUEST_BYTES = 15_000L

        @Volatile var isRunning: Boolean = false
            private set
        private val blockedCounter = java.util.concurrent.atomic.AtomicLong(0)
        val blockedCountSinceStart: Long get() = blockedCounter.get()
    }

    private var statsFlushJob: Job? = null
    private var lastFlushedBlockedCount: Long = 0

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            scope.launch { AppSettings(applicationContext).setWasProtectionOn(false) }
            stopVpn()
            return START_NOT_STICKY
        }

        val presetId = intent?.getStringExtra(EXTRA_DNS_PRESET_ID) ?: DnsPresets.CLOUDFLARE.id
        val preset = DnsPresets.ALL.firstOrNull { it.id == presetId } ?: DnsPresets.CLOUDFLARE

        // Start the tunnel immediately — don't make VPN activation wait on network
        // calls. Blocklists load in parallel and filtering kicks in progressively
        // as each list finishes; a slow/unreachable list can no longer delay or
        // block turning protection on at all.
        startVpn(preset)
        scope.launch {
            AppSettings(applicationContext).setWasProtectionOn(true)
            try {
                loadBlocklists()
            } catch (e: Exception) {
                Log.w(TAG, "Blocklist load failed, continuing with whatever was cached: ${e.message}")
            }
        }
        return START_STICKY
    }

    private suspend fun loadBlocklists() {
        val settings = AppSettings(applicationContext)
        val enabledIds = settings.enabledBlocklistIds.first()
        val customLists = settings.customBlocklists.first()
        val manualDomains = settings.manualBlockedDomains.first()
        val allowedDomains = settings.allowedDomains.first()

        val sourcesToLoad = (BlocklistSources.DEFAULTS + customLists).filter { it.id in enabledIds }
        BlocklistManager.refresh(applicationContext, sourcesToLoad)
        BlocklistManager.setManualBlockedHosts(manualDomains)
        BlocklistManager.setUserAllowedHosts(allowedDomains)
    }

    private fun startVpn(preset: DnsPreset) {
        if (isRunning) return

        upstreamPrimary = InetAddress.getByName(preset.primaryIp)

        val builder = Builder()
            .setSession("AdBlocker Pro")
            .addAddress("10.111.222.1", 24)
            .addDnsServer("10.111.222.2") // fake DNS server IP we intercept ourselves
            .addRoute("10.111.222.2", 32) // ONLY route DNS traffic through the tunnel — everything
            .setMtu(1400)                  // else stays on the normal network path (keeps it light)

        // Allow this app's own network calls (blocklist downloads) to bypass the tunnel
        try {
            builder.addDisallowedApplication(packageName)
        } catch (_ : Exception) { /* ignore if unsupported */ }

        tunInterface = builder.establish() ?: run {
            Log.e(TAG, "Failed to establish VPN interface")
            return
        }

        isRunning = true
        blockedCounter.set(0)
        com.steven.adblockerpro.data.ActivityLog.clear()
        startForeground(NOTIF_ID, buildNotification())

        // Partial wake lock: keeps the CPU able to process packets promptly even
        // when the screen is off, so aggressive OEM battery managers are less
        // likely to freeze the service mid-session (a common cause of a VPN
        // ad-blocker silently stopping after a few minutes on some phones).
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AdBlockerPro::VpnWakeLock").apply {
            setReferenceCounted(false)
            acquire(12 * 60 * 60 * 1000L) // safety cap: 12h, renewed implicitly by re-toggling
        }

        serviceJob = scope.launch { runPacketLoop() }

        // Periodically fold session counts into the lifetime totals (every 15s) rather
        // than writing to disk on every single blocked request, which would be needless
        // I/O churn on a low-end device processing many DNS lookups per minute.
        lastFlushedBlockedCount = 0
        statsFlushJob = scope.launch {
            val settings = AppSettings(applicationContext)
            while (isRunning) {
                kotlinx.coroutines.delay(15_000)
                flushStats(settings)
            }
        }

        Log.i(TAG, "VPN started, upstream=${preset.displayName}, blocklist size=${BlocklistManager.blockedCount()}")
    }

    private suspend fun flushStats(settings: AppSettings) {
        val current = blockedCountSinceStart
        val delta = current - lastFlushedBlockedCount
        if (delta > 0) {
            settings.addToLifetimeStats(delta, delta * AVG_BLOCKED_REQUEST_BYTES)
            lastFlushedBlockedCount = current
        }
    }

    private fun stopVpn() {
        isRunning = false
        serviceJob?.cancel()
        statsFlushJob?.cancel()
        scope.launch { flushStats(AppSettings(applicationContext)) } // final flush so nothing's lost on stop
        try { tunInterface?.close() } catch (_: Exception) {}
        tunInterface = null
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        Log.i(TAG, "VPN stopped")
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    override fun onRevoke() {
        scope.launch { AppSettings(applicationContext).setWasProtectionOn(false) }
        stopVpn()
        super.onRevoke()
    }

    private fun runPacketLoop() {
        val tun = tunInterface ?: return
        val input = FileInputStream(tun.fileDescriptor)
        val output = FileOutputStream(tun.fileDescriptor)
        val buffer = ByteArray(32767)

        while (isRunning) {
            val length = try { input.read(buffer) } catch (e: Exception) { break }
            if (length <= 0) continue

            // Copy immediately: `buffer` gets overwritten by the next read as soon as
            // we hand processing off to a coroutine, so each packet needs its own copy.
            val packetCopy = buffer.copyOfRange(0, length)
            scope.launch {
                try {
                    handlePacket(packetCopy, packetCopy.size, output)
                } catch (e: Exception) {
                    Log.w(TAG, "Packet handling error: ${e.message}")
                }
            }
        }
    }

    /** Parses an IPv4/UDP/DNS packet, checks the blocklist, replies or forwards. */
    private suspend fun handlePacket(packet: ByteArray, length: Int, output: FileOutputStream) {
        if (length < 20) return
        val version = (packet[0].toInt() and 0xFF) shr 4
        if (version != 4) return // IPv6 not handled in this minimal build

        val ihl = (packet[0].toInt() and 0x0F) * 4
        val protocol = packet[9].toInt() and 0xFF
        if (protocol != 17) return // UDP only — DNS runs over UDP for our purposes

        val udpStart = ihl
        val destPort = ((packet[udpStart + 2].toInt() and 0xFF) shl 8) or (packet[udpStart + 3].toInt() and 0xFF)
        if (destPort != 53) return // only intercept DNS

        val srcIp = packet.copyOfRange(12, 16)
        val destIp = packet.copyOfRange(16, 20)
        val srcPort = ((packet[udpStart].toInt() and 0xFF) shl 8) or (packet[udpStart + 1].toInt() and 0xFF)

        val dnsStart = udpStart + 8
        val dnsLength = length - dnsStart
        if (dnsLength <= 0) return
        val dnsPayload = packet.copyOfRange(dnsStart, dnsStart + dnsLength)

        val queryName = DnsMessage.extractQueryName(dnsPayload, dnsLength)

        if (queryName != null && BlocklistManager.isBlocked(queryName)) {
            blockedCounter.incrementAndGet()
            com.steven.adblockerpro.data.ActivityLog.record(queryName, blocked = true)
            val blockedReply = DnsMessage.buildBlockedResponse(dnsPayload, dnsLength)
            val replyPacket = IpV4Packet.buildUdpReply(
                sourceIp = destIp, sourcePort = 53,
                destIp = srcIp, destPort = srcPort,
                payload = blockedReply
            )
            writeLock.withLock { output.write(replyPacket) }
            return
        }

        if (queryName != null) {
            com.steven.adblockerpro.data.ActivityLog.record(queryName, blocked = false)
        }

        // Not blocked -> forward to the real upstream resolver and relay the reply back.
        // This runs on its own coroutine per packet (see runPacketLoop), so a slow or
        // unresponsive upstream server only stalls this one lookup, not every other
        // request going through the tunnel — this was the main cause of "internet
        // feels slow" with the previous single-threaded version.
        forwardToUpstream(dnsPayload, dnsLength, srcIp, srcPort, destIp, output)
    }

    private suspend fun forwardToUpstream(
        dnsPayload: ByteArray, dnsLength: Int,
        srcIp: ByteArray, srcPort: Int, destIp: ByteArray,
        output: FileOutputStream
    ) {
        val upstream = upstreamPrimary ?: return
        val socket = DatagramSocket()
        protect(socket) // exempt this socket from the VPN so it isn't routed back into itself

        try {
            socket.soTimeout = 3000
            val outPacket = DatagramPacket(dnsPayload, dnsLength, InetSocketAddress(upstream, 53))
            socket.send(outPacket)

            val replyBuf = ByteArray(512)
            val inPacket = DatagramPacket(replyBuf, replyBuf.size)
            socket.receive(inPacket)

            val replyPacket = IpV4Packet.buildUdpReply(
                sourceIp = destIp, sourcePort = 53,
                destIp = srcIp, destPort = srcPort,
                payload = replyBuf.copyOfRange(0, inPacket.length)
            )
            writeLock.withLock { output.write(replyPacket) }
        } catch (e: Exception) {
            Log.w(TAG, "Upstream forward failed: ${e.message}")
        } finally {
            socket.close()
        }
    }

    private fun buildNotification(): android.app.Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Ad Blocker", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AdBlocker Pro is active")
            .setContentText("Filtering ads & trackers on-device")
            .setSmallIcon(R.drawable.ic_shield)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }
}
