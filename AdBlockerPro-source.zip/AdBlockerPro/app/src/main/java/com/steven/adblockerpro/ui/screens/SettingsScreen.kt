package com.steven.adblockerpro.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.steven.adblockerpro.data.AppSettings
import com.steven.adblockerpro.data.DnsPresets
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(settings: AppSettings, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val selectedPreset by settings.dnsPresetId.collectAsState(initial = DnsPresets.CLOUDFLARE.id)
    val nextDnsId by settings.nextDnsConfigId.collectAsState(initial = "")
    var nextDnsFieldValue by remember(nextDnsId) { mutableStateOf(nextDnsId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DNS Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text(
                "Queries not caught by your on-device blocklists are sent to this resolver.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
            Spacer(Modifier.height(16.dp))

            DnsPresets.ALL.forEach { preset ->
                val selected = preset.id == selectedPreset
                Card(
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .selectable(selected = selected) {
                            scope.launch { settings.setDnsPreset(preset.id) }
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selected, onClick = { scope.launch { settings.setDnsPreset(preset.id) } })
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(preset.displayName, style = MaterialTheme.typography.titleMedium)
                            Text(preset.description, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                if (preset.supportsCustomId && selected) {
                    Spacer(Modifier.height(4.dp))
                    OutlinedTextField(
                        value = nextDnsFieldValue,
                        onValueChange = { nextDnsFieldValue = it },
                        label = { Text("NextDNS Config ID (from nextdns.io)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(start = 32.dp, bottom = 8.dp),
                        trailingIcon = {
                            TextButton(onClick = {
                                scope.launch { settings.setNextDnsConfigId(nextDnsFieldValue) }
                            }) { Text("Save") }
                        }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Changes apply the next time you turn protection on.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}
