package com.steven.adblockerpro.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import android.content.Intent
import android.net.Uri
import com.steven.adblockerpro.data.AppSettings
import com.steven.adblockerpro.data.DnsPresets
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(settings: AppSettings, onBack: () -> Unit, onOpenVirusTotal: () -> Unit) {
    val scope = rememberCoroutineScope()
    val selectedPreset by settings.dnsPresetId.collectAsState(initial = DnsPresets.CLOUDFLARE.id)
    val nextDnsId by settings.nextDnsConfigId.collectAsState(initial = "")
    var nextDnsFieldValue by remember(nextDnsId) { mutableStateOf(nextDnsId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DNS Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text(
                "Queries not caught by your on-device blocklists are sent to this resolver.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
            Spacer(Modifier.height(16.dp))

            DnsPresets.ALL.forEach { preset ->
                val selected = preset.id == selectedPreset
                Card(
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .selectable(selected = selected) {
                            scope.launch { settings.setDnsPreset(preset.id) }
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selected, onClick = { scope.launch { settings.setDnsPreset(preset.id) } })
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(preset.displayName, style = MaterialTheme.typography.titleMedium)
                            Text(preset.description, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                if (preset.supportsCustomId && selected) {
                    Spacer(Modifier.height(4.dp))
                    OutlinedTextField(
                        value = nextDnsFieldValue,
                        onValueChange = { nextDnsFieldValue = it },
                        label = { Text("NextDNS Config ID (from nextdns.io)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(start = 32.dp, bottom = 8.dp),
                        trailingIcon = {
                            TextButton(onClick = {
                                scope.launch { settings.setNextDnsConfigId(nextDnsFieldValue) }
                            }) { Text("Save") }
                        }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Changes apply the next time you turn protection on.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )

            HorizontalDivider(Modifier.padding(vertical = 20.dp))
            ThemeSection(settings)

            HorizontalDivider(Modifier.padding(vertical = 20.dp))
            AutoStartSection(settings)

            HorizontalDivider(Modifier.padding(vertical = 20.dp))
            ManualBlockSection(settings)

            HorizontalDivider(Modifier.padding(vertical = 20.dp))
            AllowlistSection(settings)

            HorizontalDivider(Modifier.padding(vertical = 20.dp))
            Text("Domain reputation", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "Check a specific domain against VirusTotal on demand.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onOpenVirusTotal) { Text("Open VirusTotal Check") }

            HorizontalDivider(Modifier.padding(vertical = 20.dp))
            BugReportSection()
        }
    }
}

@Composable
private fun ThemeSection(settings: AppSettings) {
    val scope = rememberCoroutineScope()
    val current by settings.themeMode.collectAsState(initial = "system")

    Text("Appearance", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
    Text(
        "If dark mode isn't following your system setting correctly on this phone, force it here instead.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
    )
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("system" to "Auto", "light" to "Light", "dark" to "Dark").forEach { (value, label) ->
            FilterChip(
                selected = current == value,
                onClick = { scope.launch { settings.setThemeMode(value) } },
                label = { Text(label) }
            )
        }
    }
}

@Composable
private fun AutoStartSection(settings: AppSettings) {
    val scope = rememberCoroutineScope()
    val autoStart by settings.autoStartEnabled.collectAsState(initial = true)

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Launch automatically", style = MaterialTheme.typography.titleMedium)
            Text(
                "Turns protection back on by itself after your phone restarts, if it was on before.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
        Switch(checked = autoStart, onCheckedChange = { scope.launch { settings.setAutoStartEnabled(it) } })
    }
}

@Composable
private fun ManualBlockSection(settings: AppSettings) {
    val scope = rememberCoroutineScope()
    val blockedDomains by settings.manualBlockedDomains.collectAsState(initial = emptySet())
    var domainInput by remember { mutableStateOf("") }

    Text("Block a specific domain", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
    Text(
        "Add any single domain directly — no need to add a whole list or rebuild the app for one-off blocks. Takes effect next time you start protection.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
    )
    Spacer(Modifier.height(8.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = domainInput,
            onValueChange = { domainInput = it },
            label = { Text("e.g. ads.example.com") },
            singleLine = true,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        TextButton(onClick = {
            if (domainInput.isNotBlank()) {
                scope.launch { settings.addManualBlockedDomain(domainInput) }
                domainInput = ""
            }
        }) { Text("Add") }
    }

    blockedDomains.forEach { domain ->
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(domain, style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = { scope.launch { settings.removeManualBlockedDomain(domain) } }) {
                Text("Remove")
            }
        }
    }
}

@Composable
private fun AllowlistSection(settings: AppSettings) {
    val scope = rememberCoroutineScope()
    val allowedDomains by settings.allowedDomains.collectAsState(initial = emptySet())
    var domainInput by remember { mutableStateOf("") }

    Text("Allowlist", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
    Text(
        "Domains here are never blocked, even if they're on one of your blocklists — use this if a site breaks.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
    )
    Spacer(Modifier.height(8.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = domainInput,
            onValueChange = { domainInput = it },
            label = { Text("e.g. checkout.somesite.com") },
            singleLine = true,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        TextButton(onClick = {
            if (domainInput.isNotBlank()) {
                scope.launch { settings.addAllowedDomain(domainInput) }
                domainInput = ""
            }
        }) { Text("Add") }
    }

    allowedDomains.forEach { domain ->
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(domain, style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = { scope.launch { settings.removeAllowedDomain(domain) } }) {
                Text("Remove")
            }
        }
    }
}

@Composable
private fun BugReportSection() {
    val context = LocalContext.current
    val supportEmail = "mosamy518@gmail.com"

    Text("Found a bug?", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
    Text(
        "Report it and it'll come straight to $supportEmail.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
    )
    Spacer(Modifier.height(8.dp))
    Button(onClick = {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$supportEmail")
            putExtra(Intent.EXTRA_SUBJECT, "AdBlocker Pro bug report")
        }
        context.startActivity(Intent.createChooser(intent, "Send bug report"))
    }) {
        Text("Email a bug report")
    }
}
