package com.steven.adblockerpro.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap

/**
 * Downloads blocklists (hosts-file format OR AdBlock/uBlock filter-list
 * format), extracts plain hostnames from each, and keeps a single merged,
 * deduped set in memory for O(1) lookup from the VPN thread.
 *
 * Kept deliberately simple (a HashSet, not a trie) — for the ~1-2 million
 * domains a combined list produces, a HashSet lookup is still sub-microsecond
 * and far simpler to keep correct than a compressed trie, which matters more
 * on low-end devices than the last few % of memory.
 */
object BlocklistManager {

    private const val TAG = "BlocklistManager"
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    // Thread-safe: written on a background refresh, read constantly from the VPN thread
    @Volatile
    private var blockedHosts: Set<String> = emptySet()

    private val allowedHosts = ConcurrentHashMap.newKeySet<String>() // user-added + list-based exceptions
    private val manualBlockedHosts = ConcurrentHashMap.newKeySet<String>() // user-added single domains
    private val listExceptionHosts = ConcurrentHashMap.newKeySet<String>() // from isExceptionList sources (e.g. uBlock's unbreak.txt)

    fun isBlocked(host: String): Boolean {
        if (host.isEmpty()) return false
        val h = host.lowercase().removeSuffix(".")
        if (allowedHosts.contains(h) || listExceptionHosts.contains(h)) return false
        if (manualBlockedHosts.contains(h)) return true
        // check exact host, then walk up parent domains (blocks subdomains too)
        var current = h
        while (true) {
            if (blockedHosts.contains(current)) return true
            val dot = current.indexOf('.')
            if (dot < 0) break
            current = current.substring(dot + 1)
        }
        return false
    }

    fun allowHost(host: String) {
        allowedHosts.add(host.lowercase())
    }

    /** Called at startup (and whenever the user adds/removes one) to sync the persisted allowlist. */
    fun setUserAllowedHosts(hosts: Set<String>) {
        allowedHosts.clear()
        allowedHosts.addAll(hosts.map { it.lowercase() })
    }

    /** Called at startup (and whenever the user adds/removes one) to sync manually-blocked domains. */
    fun setManualBlockedHosts(hosts: Set<String>) {
        manualBlockedHosts.clear()
        manualBlockedHosts.addAll(hosts.map { it.lowercase() })
    }

    fun blockedCount(): Int = blockedHosts.size + manualBlockedHosts.size

    /**
     * Downloads every enabled source **in parallel** and rebuilds the merged in-memory set.
     * Parallelizing (rather than one-at-a-time) matters a lot here: with several lists
     * enabled by default, sequential downloads on a slow connection could take minutes
     * before finishing — which, when this used to gate VPN startup, looked like the app
     * "wouldn't turn on." It no longer gates startup at all (see AdBlockVpnService), but
     * kept parallel anyway since there's no reason to make people wait longer than necessary.
     */
    suspend fun refresh(context: Context, sources: List<BlocklistSource>) = withContext(Dispatchers.IO) {
        val cacheDir = File(context.filesDir, "blocklists").apply { mkdirs() }
        val merged = HashSet<String>(500_000)
        val exceptions = HashSet<String>(5_000)

        val results = sources.map { source ->
            async {
                try {
                    val text = downloadOrUseCache(source, cacheDir)
                    source to (if (source.isExceptionList) parseExceptionHostnames(text) else parseToHostnames(text))
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to refresh ${source.name}: ${e.message}")
                    val cached = File(cacheDir, "${source.id}.txt")
                    val fallback = if (cached.exists()) {
                        val cachedText = cached.readText()
                        if (source.isExceptionList) parseExceptionHostnames(cachedText) else parseToHostnames(cachedText)
                    } else emptySet()
                    source to fallback
                }
            }
        }.awaitAll()

        for ((source, hosts) in results) {
            if (source.isExceptionList) exceptions.addAll(hosts) else merged.addAll(hosts)
        }

        blockedHosts = merged
        listExceptionHosts.clear()
        listExceptionHosts.addAll(exceptions)
        Log.i(TAG, "Blocklist refreshed: ${merged.size} hosts blocked, ${exceptions.size} exceptions")
    }

    private fun downloadOrUseCache(source: BlocklistSource, cacheDir: File): String {
        val request = Request.Builder().url(source.url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw java.io.IOException("HTTP ${response.code}")
            val body = response.body?.string() ?: throw java.io.IOException("Empty body")
            File(cacheDir, "${source.id}.txt").writeText(body)
            return body
        }
    }

    /**
     * Handles two common formats:
     *  - hosts file: "0.0.0.0 ads.example.com"
     *  - AdBlock/uBlock filter syntax: "||ads.example.com^"
     * Anything else (cosmetic rules, comments, exceptions) is skipped.
     */
    internal fun parseToHostnames(text: String): Set<String> {
        val result = HashSet<String>()
        for (rawLine in text.lineSequence()) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("!")) continue
            if (line.startsWith("@@")) continue // whitelist rule, skip

            when {
                line.startsWith("||") -> {
                    val end = line.indexOf('^').let { if (it == -1) line.length else it }
                    val host = line.substring(2, end).substringBefore("/")
                    if (isValidHost(host)) result.add(host.lowercase())
                }
                line.startsWith("0.0.0.0 ") || line.startsWith("127.0.0.1 ") -> {
                    val host = line.substringAfter(' ').trim().substringBefore(' ')
                    if (isValidHost(host) && host != "localhost") result.add(host.lowercase())
                }
                !line.contains('/') && !line.contains('*') && !line.contains('$') &&
                    !line.contains('^') && line.contains('.') && !line.contains(' ') -> {
                    // bare-domain list format (e.g. OISD wildcard list)
                    if (isValidHost(line)) result.add(line.lowercase())
                }
            }
        }
        return result
    }

    private fun isValidHost(host: String): Boolean {
        if (host.isEmpty() || host.length > 253) return false
        return host.matches(Regex("^[a-zA-Z0-9.-]+$"))
    }

    /** Extracts hostnames from "@@||domain^" style exception rules (e.g. uBlock's unbreak.txt). */
    internal fun parseExceptionHostnames(text: String): Set<String> {
        val result = HashSet<String>()
        for (rawLine in text.lineSequence()) {
            val line = rawLine.trim()
            if (!line.startsWith("@@||")) continue
            val end = line.indexOf('^').let { if (it == -1) line.length else it }
            val host = line.substring(4, end).substringBefore("/")
            if (isValidHost(host)) result.add(host.lowercase())
        }
        return result
    }
}
