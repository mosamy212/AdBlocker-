package com.steven.adblockerpro.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap

/**
 * Downloads blocklists (hosts-file format OR AdBlock/uBlock filter-list
 * format), extracts plain hostnames from each, and keeps a single merged,
 * deduped set in memory for O(1) lookup from the VPN thread.
 *
 * Kept deliberately simple (a HashSet, not a trie) — for the ~1-2 million
 * domains a combined list produces, a HashSet lookup is still sub-microsecond
 * and far simpler to keep correct than a compressed trie, which matters more
 * on low-end devices than the last few % of memory.
 */
object BlocklistManager {

    private const val TAG = "BlocklistManager"
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Thread-safe: written on a background refresh, read constantly from the VPN thread
    @Volatile
    private var blockedHosts: Set<String> = emptySet()

    private val allowedHosts = ConcurrentHashMap.newKeySet<String>() // user-added exceptions
    private val manualBlockedHosts = ConcurrentHashMap.newKeySet<String>() // user-added single domains

    fun isBlocked(host: String): Boolean {
        if (host.isEmpty()) return false
        val h = host.lowercase().removeSuffix(".")
        if (allowedHosts.contains(h)) return false
        if (manualBlockedHosts.contains(h)) return true
        // check exact host, then walk up parent domains (blocks subdomains too)
        var current = h
        while (true) {
            if (blockedHosts.contains(current)) return true
            val dot = current.indexOf('.')
            if (dot < 0) break
            current = current.substring(dot + 1)
        }
        return false
    }

    fun allowHost(host: String) {
        allowedHosts.add(host.lowercase())
    }

    /** Called at startup (and whenever the user adds/removes one) to sync manually-blocked domains. */
    fun setManualBlockedHosts(hosts: Set<String>) {
        manualBlockedHosts.clear()
        manualBlockedHosts.addAll(hosts.map { it.lowercase() })
    }

    fun blockedCount(): Int = blockedHosts.size + manualBlockedHosts.size

    /** Downloads every enabled source and rebuilds the merged in-memory set. */
    suspend fun refresh(context: Context, sources: List<BlocklistSource>) = withContext(Dispatchers.IO) {
        val cacheDir = File(context.filesDir, "blocklists").apply { mkdirs() }
        val merged = HashSet<String>(500_000)

        for (source in sources) {
            try {
                val text = downloadOrUseCache(source, cacheDir)
                merged.addAll(parseToHostnames(text))
            } catch (e: Exception) {
                Log.w(TAG, "Failed to refresh ${source.name}: ${e.message}")
                // fall back silently to whatever cached hosts we already parsed from disk
                val cached = File(cacheDir, "${source.id}.txt")
                if (cached.exists()) {
                    merged.addAll(parseToHostnames(cached.readText()))
                }
            }
        }
        blockedHosts = merged
        Log.i(TAG, "Blocklist refreshed: ${merged.size} hosts")
    }

    private fun downloadOrUseCache(source: BlocklistSource, cacheDir: File): String {
        val request = Request.Builder().url(source.url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw java.io.IOException("HTTP ${response.code}")
            val body = response.body?.string() ?: throw java.io.IOException("Empty body")
            File(cacheDir, "${source.id}.txt").writeText(body)
            return body
        }
    }

    /**
     * Handles two common formats:
     *  - hosts file: "0.0.0.0 ads.example.com"
     *  - AdBlock/uBlock filter syntax: "||ads.example.com^"
     * Anything else (cosmetic rules, comments, exceptions) is skipped.
     */
    internal fun parseToHostnames(text: String): Set<String> {
        val result = HashSet<String>()
        for (rawLine in text.lineSequence()) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("!")) continue
            if (line.startsWith("@@")) continue // whitelist rule, skip

            when {
                line.startsWith("||") -> {
                    val end = line.indexOf('^').let { if (it == -1) line.length else it }
                    val host = line.substring(2, end).substringBefore("/")
                    if (isValidHost(host)) result.add(host.lowercase())
                }
                line.startsWith("0.0.0.0 ") || line.startsWith("127.0.0.1 ") -> {
                    val host = line.substringAfter(' ').trim().substringBefore(' ')
                    if (isValidHost(host) && host != "localhost") result.add(host.lowercase())
                }
                !line.contains('/') && !line.contains('*') && !line.contains('$') &&
                    !line.contains('^') && line.contains('.') && !line.contains(' ') -> {
                    // bare-domain list format (e.g. OISD wildcard list)
                    if (isValidHost(line)) result.add(line.lowercase())
                }
            }
        }
        return result
    }

    private fun isValidHost(host: String): Boolean {
        if (host.isEmpty() || host.length > 253) return false
        return host.matches(Regex("^[a-zA-Z0-9.-]+$"))
    }
}
