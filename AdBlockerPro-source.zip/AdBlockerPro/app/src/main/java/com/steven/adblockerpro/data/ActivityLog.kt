package com.steven.adblockerpro.data

import java.util.concurrent.ConcurrentLinkedDeque

data class LogEntry(
    val domain: String,
    val blocked: Boolean,
    val timestampMillis: Long
)

/**
 * Keeps the last [MAX_ENTRIES] DNS lookups in memory so the Activity Log
 * screen can show "what I opened / what got blocked." Deliberately
 * in-memory only (not persisted to disk) — this is a live session view,
 * not a permanent history, which keeps it fast and avoids storing a
 * detailed browsing log on disk long-term for privacy reasons.
 */
object ActivityLog {
    private const val MAX_ENTRIES = 300
    private val entries = ConcurrentLinkedDeque<LogEntry>()

    fun record(domain: String, blocked: Boolean) {
        entries.addFirst(LogEntry(domain, blocked, System.currentTimeMillis()))
        while (entries.size > MAX_ENTRIES) entries.removeLast()
    }

    fun recent(): List<LogEntry> = entries.toList()

    fun clear() = entries.clear()
}
