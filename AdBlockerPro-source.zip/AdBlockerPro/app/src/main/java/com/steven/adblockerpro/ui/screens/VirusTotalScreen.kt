package com.steven.adblockerpro.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.steven.adblockerpro.data.AppSettings
import com.steven.adblockerpro.data.VirusTotalClient
import com.steven.adblockerpro.data.VirusTotalOutcome
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class VtMode { DOMAIN, URL, FILE }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VirusTotalScreen(settings: AppSettings, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val apiKey by settings.virusTotalApiKey.collectAsState(initial = "")
    var apiKeyInput by remember(apiKey) { mutableStateOf(apiKey) }

    var mode by remember { mutableStateOf(VtMode.DOMAIN) }
    var textInput by remember { mutableStateOf("") }
    var selectedFileUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var outcome by remember { mutableStateOf<VirusTotalOutcome?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedFileUri = uri
        selectedFileName = uri?.let { queryFileName(context, it) }
        outcome = null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("VirusTotal Check") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text(
                "Runs the target through VirusTotal's full set of antivirus engines at once — same as using virustotal.com directly. On-demand only (not part of live ad blocking — see Settings for why).",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )

            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = apiKeyInput,
                onValueChange = { apiKeyInput = it },
                label = { Text("VirusTotal API key (free at virustotal.com)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = {
                    TextButton(onClick = { scope.launch { settings.setVirusTotalApiKey(apiKeyInput) } }) { Text("Save") }
                }
            )

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = mode == VtMode.DOMAIN, onClick = { mode = VtMode.DOMAIN; outcome = null }, label = { Text("Domain") })
                FilterChip(selected = mode == VtMode.URL, onClick = { mode = VtMode.URL; outcome = null }, label = { Text("URL") })
                FilterChip(selected = mode == VtMode.FILE, onClick = { mode = VtMode.FILE; outcome = null }, label = { Text("File") })
            }

            Spacer(Modifier.height(16.dp))

            when (mode) {
                VtMode.DOMAIN, VtMode.URL -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            label = { Text(if (mode == VtMode.DOMAIN) "Domain to check" else "URL to scan") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(
                            enabled = !loading,
                            onClick = {
                                loading = true
                                outcome = null
                                statusMessage = if (mode == VtMode.URL) "Submitting for analysis…" else null
                                scope.launch {
                                    outcome = if (mode == VtMode.DOMAIN) {
                                        VirusTotalClient.checkDomain(textInput, apiKey)
                                    } else {
                                        VirusTotalClient.scanUrl(textInput, apiKey)
                                    }
                                    loading = false
                                    statusMessage = null
                                }
                            }
                        ) { Text("Check") }
                    }
                }
                VtMode.FILE -> {
                    Button(onClick = { filePicker.launch("*/*") }) {
                        Icon(Icons.Default.UploadFile, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(selectedFileName ?: "Choose a file")
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        enabled = !loading && selectedFileUri != null,
                        onClick = {
                            val uri = selectedFileUri ?: return@Button
                            val name = selectedFileName ?: "file"
                            loading = true
                            outcome = null
                            statusMessage = "Uploading and scanning…"
                            scope.launch {
                                val bytes = withContext(Dispatchers.IO) {
                                    try {
                                        context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                                    } catch (e: Exception) { null }
                                }
                                outcome = if (bytes == null) {
                                    VirusTotalOutcome.Error("Couldn't read that file.")
                                } else {
                                    VirusTotalClient.scanFile(bytes, name, apiKey)
                                }
                                loading = false
                                statusMessage = null
                            }
                        }
                    ) { Text("Scan file") }
                }
            }

            Spacer(Modifier.height(20.dp))
            if (loading) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    statusMessage?.let {
                        Spacer(Modifier.height(8.dp))
                        Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                }
            }

            outcome?.let { result ->
                when (result) {
                    is VirusTotalOutcome.Error -> Text(result.message, color = MaterialTheme.colorScheme.error)
                    is VirusTotalOutcome.Success -> {
                        val r = result.result
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (r.isFlagged) MaterialTheme.colorScheme.errorContainer
                                else MaterialTheme.colorScheme.primaryContainer
                            )
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(
                                    if (r.isFlagged) "⚠ Flagged by security vendors" else "✓ Looks clean",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Spacer(Modifier.height(8.dp))
                                Text("${r.maliciousCount} malicious / ${r.suspiciousCount} suspicious / ${r.harmlessCount} harmless — out of ${r.totalEngines} engines")
                                if (r.isFlagged && mode == VtMode.DOMAIN) {
                                    Spacer(Modifier.height(12.dp))
                                    Button(onClick = { scope.launch { settings.addManualBlockedDomain(r.target) } }) {
                                        Text("Add to denylist")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun queryFileName(context: android.content.Context, uri: Uri): String? {
    return try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else uri.lastPathSegment
        } ?: uri.lastPathSegment
    } catch (e: Exception) {
        uri.lastPathSegment
    }
}
