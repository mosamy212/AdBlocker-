package com.steven.adblockerpro

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.steven.adblockerpro.data.AppSettings
import com.steven.adblockerpro.data.DnsPresets
import com.steven.adblockerpro.ui.screens.ActivityLogScreen
import com.steven.adblockerpro.ui.screens.BlocklistsScreen
import com.steven.adblockerpro.ui.screens.HomeScreen
import com.steven.adblockerpro.ui.screens.SettingsScreen
import com.steven.adblockerpro.ui.screens.VirusTotalScreen
import com.steven.adblockerpro.ui.theme.AdBlockerProTheme
import com.steven.adblockerpro.vpn.AdBlockVpnService

class MainActivity : ComponentActivity() {

    private lateinit var settings: AppSettings
    private var pendingStart = false

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && pendingStart) {
            launchVpnService()
        }
        pendingStart = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = AppSettings(this)

        setContent {
            val themeMode by settings.themeMode.collectAsState(initial = "system")
            AdBlockerProTheme(themeOverride = themeMode) {
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "home") {
                    composable("home") {
                        HomeScreen(
                            settings = settings,
                            isRunning = { AdBlockVpnService.isRunning },
                            blockedCount = { AdBlockVpnService.blockedCountSinceStart },
                            onToggleProtection = { turnOn ->
                                if (turnOn) requestVpnPermissionAndStart() else stopVpnService()
                            },
                            onOpenBlocklists = { navController.navigate("blocklists") },
                            onOpenSettings = { navController.navigate("settings") },
                            onOpenActivity = { navController.navigate("activity") }
                        )
                    }
                    composable("blocklists") {
                        BlocklistsScreen(settings = settings, onBack = { navController.popBackStack() })
                    }
                    composable("settings") {
                        SettingsScreen(
                            settings = settings,
                            onBack = { navController.popBackStack() },
                            onOpenVirusTotal = { navController.navigate("virustotal") }
                        )
                    }
                    composable("activity") {
                        ActivityLogScreen(settings = settings, onBack = { navController.popBackStack() })
                    }
                    composable("virustotal") {
                        VirusTotalScreen(settings = settings, onBack = { navController.popBackStack() })
                    }
                }
            }
        }
    }

    private fun requestVpnPermissionAndStart() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            pendingStart = true
            vpnPermissionLauncher.launch(intent)
        } else {
            launchVpnService()
        }
    }

    private fun launchVpnService() {
        lifecycleScope.launch {
            val presetId = settings.dnsPresetId.first()
            val intent = Intent(this@MainActivity, AdBlockVpnService::class.java)
            intent.putExtra(AdBlockVpnService.EXTRA_DNS_PRESET_ID, presetId)
            startForegroundService(intent)
        }
    }

    private fun stopVpnService() {
        val intent = Intent(this, AdBlockVpnService::class.java)
        intent.action = AdBlockVpnService.ACTION_STOP
        startService(intent)
    }
}
