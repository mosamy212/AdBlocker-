package com.steven.adblockerpro.vpn

/**
 * Minimal, dependency-free DNS message helpers. We only need to:
 *  1. Pull the queried hostname out of a raw DNS query.
 *  2. Build an NXDOMAIN reply for blocked hostnames, reusing the original
 *     transaction ID and question section so the requesting app accepts it.
 *
 * This intentionally does not implement full DNS (no compression pointer
 * writing, no record types beyond what's needed) — keeping it small keeps
 * per-packet CPU cost low, which matters on older/low-end phones.
 */
object DnsMessage {

    /** Returns the queried domain name (e.g. "ads.example.com"), or null if unparseable. */
    fun extractQueryName(packet: ByteArray, length: Int): String? {
        if (length < 12) return null // header alone is 12 bytes
        val qdCount = ((packet[4].toInt() and 0xFF) shl 8) or (packet[5].toInt() and 0xFF)
        if (qdCount < 1) return null

        val sb = StringBuilder()
        var pos = 12
        while (pos < length) {
            val len = packet[pos].toInt() and 0xFF
            if (len == 0) { pos++; break }
            if (len and 0xC0 == 0xC0) return null // compression pointer in a query is unusual; bail safely
            pos++
            if (pos + len > length) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(packet, pos, len, Charsets.US_ASCII))
            pos += len
        }
        return if (sb.isEmpty()) null else sb.toString()
    }

    /**
     * Builds a reply to [query] (the original raw DNS query bytes) that says
     * "this domain does not exist" (RCODE 3 / NXDOMAIN), which every app and
     * OS DNS client treats as "no ads to load here" and moves on cleanly.
     */
    fun buildBlockedResponse(query: ByteArray, length: Int): ByteArray {
        val response = query.copyOf(length)
        // Flags: byte 2 -> QR=1 (response), Opcode=0, AA=0, TC=0, RD copied from query
        response[2] = (0x80 or (query[2].toInt() and 0x01)).toByte()
        // byte 3 -> RA=1, Z=0, RCODE=3 (NXDOMAIN)
        response[3] = 0x83.toByte()
        // ANCOUNT / NSCOUNT / ARCOUNT = 0 (bytes 6-11) — question already has QDCOUNT set
        response[6] = 0; response[7] = 0
        response[8] = 0; response[9] = 0
        response[10] = 0; response[11] = 0
        return response
    }
}
