package com.steven.adblockerpro.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class VirusTotalResult(
    val target: String,
    val maliciousCount: Int,
    val suspiciousCount: Int,
    val harmlessCount: Int,
    val totalEngines: Int
) {
    val isFlagged: Boolean get() = maliciousCount > 0 || suspiciousCount > 0
}

sealed class VirusTotalOutcome {
    data class Success(val result: VirusTotalResult) : VirusTotalOutcome()
    data class Error(val message: String) : VirusTotalOutcome()
}

/**
 * On-demand VirusTotal checks (domain / URL / file) — NOT wired into live DNS
 * filtering. VirusTotal's free API is rate-limited to 4 requests/minute, far
 * too slow for real-time filtering of ordinary browsing traffic. Each check
 * here runs the target through VirusTotal's full set of antivirus engines at
 * once and aggregates the verdict, same as using virustotal.com directly.
 */
object VirusTotalClient {
    private const val MAX_FILE_SIZE_BYTES = 32L * 1024 * 1024 // 32MB — free-tier VT upload limit
    private const val POLL_INTERVAL_MS = 3000L
    private const val MAX_POLL_ATTEMPTS = 15 // ~45s max wait for an analysis to finish

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS) // file uploads can take longer
        .build()

    suspend fun checkDomain(domain: String, apiKey: String): VirusTotalOutcome = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext noKeyError()
        val clean = domain.trim().lowercase().removePrefix("http://").removePrefix("https://").substringBefore("/")
        if (clean.isEmpty()) return@withContext VirusTotalOutcome.Error("Enter a domain first.")

        try {
            val request = Request.Builder()
                .url("https://www.virustotal.com/api/v3/domains/$clean")
                .addHeader("x-apikey", apiKey)
                .build()

            client.newCall(request).execute().use { response ->
                handleErrorCodes(response.code)?.let { return@withContext it }
                if (!response.isSuccessful) return@withContext VirusTotalOutcome.Error("VirusTotal error: HTTP ${response.code}")

                val body = response.body?.string() ?: return@withContext VirusTotalOutcome.Error("Empty response")
                val stats = JSONObject(body).getJSONObject("data").getJSONObject("attributes").getJSONObject("last_analysis_stats")
                VirusTotalOutcome.Success(statsToResult(clean, stats))
            }
        } catch (e: Exception) {
            VirusTotalOutcome.Error("Lookup failed: ${e.message}")
        }
    }

    suspend fun scanUrl(urlToScan: String, apiKey: String): VirusTotalOutcome = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext noKeyError()
        val clean = urlToScan.trim()
        if (clean.isEmpty()) return@withContext VirusTotalOutcome.Error("Enter a URL first.")

        try {
            val body = "url=$clean".toRequestBody("application/x-www-form-urlencoded".toMediaType())
            val request = Request.Builder()
                .url("https://www.virustotal.com/api/v3/urls")
                .addHeader("x-apikey", apiKey)
                .post(body)
                .build()

            val analysisId = client.newCall(request).execute().use { response ->
                handleErrorCodes(response.code)?.let { return@withContext it }
                if (!response.isSuccessful) return@withContext VirusTotalOutcome.Error("VirusTotal error: HTTP ${response.code}")
                val responseBody = response.body?.string() ?: return@withContext VirusTotalOutcome.Error("Empty response")
                JSONObject(responseBody).getJSONObject("data").getString("id")
            }

            pollAnalysis(analysisId, clean, apiKey)
        } catch (e: Exception) {
            VirusTotalOutcome.Error("URL scan failed: ${e.message}")
        }
    }

    suspend fun scanFile(fileBytes: ByteArray, fileName: String, apiKey: String): VirusTotalOutcome = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext noKeyError()
        if (fileBytes.isEmpty()) return@withContext VirusTotalOutcome.Error("Couldn't read that file.")
        if (fileBytes.size > MAX_FILE_SIZE_BYTES) {
            return@withContext VirusTotalOutcome.Error("File is too large — VirusTotal's free tier allows up to 32MB.")
        }

        try {
            val multipart = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(
                    "file", fileName,
                    fileBytes.toRequestBody("application/octet-stream".toMediaType())
                )
                .build()

            val request = Request.Builder()
                .url("https://www.virustotal.com/api/v3/files")
                .addHeader("x-apikey", apiKey)
                .post(multipart)
                .build()

            val analysisId = client.newCall(request).execute().use { response ->
                handleErrorCodes(response.code)?.let { return@withContext it }
                if (!response.isSuccessful) return@withContext VirusTotalOutcome.Error("VirusTotal error: HTTP ${response.code}")
                val responseBody = response.body?.string() ?: return@withContext VirusTotalOutcome.Error("Empty response")
                JSONObject(responseBody).getJSONObject("data").getString("id")
            }

            pollAnalysis(analysisId, fileName, apiKey)
        } catch (e: Exception) {
            VirusTotalOutcome.Error("File scan failed: ${e.message}")
        }
    }

    /** URL and file scans are async on VirusTotal's side — poll until the analysis finishes. */
    private suspend fun pollAnalysis(analysisId: String, targetLabel: String, apiKey: String): VirusTotalOutcome {
        repeat(MAX_POLL_ATTEMPTS) { attempt ->
            val request = Request.Builder()
                .url("https://www.virustotal.com/api/v3/analyses/$analysisId")
                .addHeader("x-apikey", apiKey)
                .build()

            client.newCall(request).execute().use { response ->
                handleErrorCodes(response.code)?.let { return it }
                if (!response.isSuccessful) return VirusTotalOutcome.Error("VirusTotal error: HTTP ${response.code}")

                val body = response.body?.string() ?: return VirusTotalOutcome.Error("Empty response")
                val attributes = JSONObject(body).getJSONObject("data").getJSONObject("attributes")
                val status = attributes.optString("status")

                if (status == "completed") {
                    val stats = attributes.getJSONObject("stats")
                    return VirusTotalOutcome.Success(statsToResult(targetLabel, stats))
                }
            }
            delay(POLL_INTERVAL_MS)
        }
        return VirusTotalOutcome.Error("Analysis is taking longer than usual — VirusTotal is still scanning. Try checking again in a minute.")
    }

    private fun statsToResult(target: String, stats: JSONObject): VirusTotalResult {
        val malicious = stats.optInt("malicious", 0)
        val suspicious = stats.optInt("suspicious", 0)
        val harmless = stats.optInt("harmless", 0)
        val total = malicious + suspicious + harmless + stats.optInt("undetected", 0)
        return VirusTotalResult(target, malicious, suspicious, harmless, total)
    }

    private fun handleErrorCodes(code: Int): VirusTotalOutcome.Error? = when (code) {
        401 -> VirusTotalOutcome.Error("Invalid API key.")
        404 -> VirusTotalOutcome.Error("VirusTotal has no data on this yet.")
        429 -> VirusTotalOutcome.Error("Rate limit hit (free tier allows 4 requests/minute) — wait a bit and try again.")
        else -> null
    }

    private fun noKeyError() = VirusTotalOutcome.Error("No VirusTotal API key set — add yours in Settings first (get a free one at virustotal.com).")
}
