package com.steven.adblockerpro.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.steven.adblockerpro.data.AppSettings
import com.steven.adblockerpro.data.BlocklistManager
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    settings: AppSettings,
    isRunning: () -> Boolean,
    blockedCount: () -> Long,
    onToggleProtection: (Boolean) -> Unit,
    onOpenBlocklists: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenActivity: () -> Unit
) {
    var running by remember { mutableStateOf(isRunning()) }
    var sessionBlocked by remember { mutableStateOf(blockedCount()) }
    val lifetimeBlocked by settings.totalBlockedLifetime.collectAsState(initial = 0L)
    val lifetimeDataSaved by settings.totalDataSavedBytes.collectAsState(initial = 0L)

    LaunchedEffect(Unit) {
        while (true) {
            running = isRunning()
            sessionBlocked = blockedCount()
            delay(1000)
        }
    }

    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 1f,
        targetValue = if (running) 1.06f else 1f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "pulseAnim"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AdBlocker Pro", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineLarge) },
                actions = {
                    IconButton(onClick = onOpenActivity) { Icon(Icons.Default.History, contentDescription = "Activity") }
                    IconButton(onClick = onOpenBlocklists) { Icon(Icons.Default.List, contentDescription = "Blocklists") }
                    IconButton(onClick = onOpenSettings) { Icon(Icons.Default.Settings, contentDescription = "Settings") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(28.dp))

            val ringColor = if (running) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .scale(if (running) pulse else 1f)
                    .clip(CircleShape)
                    .background(ringColor.copy(alpha = 0.14f))
                    .clickable { onToggleProtection(!running) },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .clip(CircleShape)
                        .background(ringColor.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = ringColor, modifier = Modifier.size(96.dp))
                }
            }

            Spacer(Modifier.height(24.dp))
            Text(
                text = if (running) "Protected" else "Not protected",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (running) "Tap the shield to pause" else "Tap the shield to start",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )

            Spacer(Modifier.height(28.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BigStatCard(
                    modifier = Modifier.weight(1f),
                    value = formatCount(lifetimeBlocked),
                    label = "Ads blocked (all time)"
                )
                BigStatCard(
                    modifier = Modifier.weight(1f),
                    value = formatBytes(lifetimeDataSaved),
                    label = "Data saved (est.)"
                )
            }

            Spacer(Modifier.height(12.dp))

            Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    StatRow("Blocked this session", sessionBlocked.toString())
                    Spacer(Modifier.height(10.dp))
                    StatRow("Domains in active blocklist", formatCount(BlocklistManager.blockedCount().toLong()))
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "\"Data saved\" is an estimate based on typical ad size — for your actual data usage, check your phone's Settings → Network → Data usage.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun BigStatCard(modifier: Modifier = Modifier, value: String, label: String) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.padding(vertical = 20.dp, horizontal = 16.dp)) {
            Text(value, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
    }
}

private fun formatCount(n: Long): String = when {
    n >= 1_000_000 -> "%.1fM".format(n / 1_000_000.0)
    n >= 1_000 -> "%.1fK".format(n / 1_000.0)
    else -> n.toString()
}

private fun formatBytes(bytes: Long): String {
    val mb = bytes / 1_000_000.0
    return when {
        mb >= 1000 -> "%.1f GB".format(mb / 1000.0)
        mb >= 1 -> "%.1f MB".format(mb)
        else -> "%.0f KB".format(bytes / 1000.0)
    }
}
