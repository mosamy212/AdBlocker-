package com.steven.adblockerpro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.steven.adblockerpro.data.AppSettings
import com.steven.adblockerpro.data.BlocklistManager
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    settings: AppSettings,
    isRunning: () -> Boolean,
    blockedCount: () -> Long,
    onToggleProtection: (Boolean) -> Unit,
    onOpenBlocklists: () -> Unit,
    onOpenSettings: () -> Unit
) {
    var running by remember { mutableStateOf(isRunning()) }
    var blocked by remember { mutableStateOf(blockedCount()) }

    // Lightweight poll so the counter updates live without a heavier event-bus dependency
    LaunchedEffect(Unit) {
        while (true) {
            running = isRunning()
            blocked = blockedCount()
            delay(1000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AdBlocker Pro", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onOpenBlocklists) {
                        Icon(Icons.Default.List, contentDescription = "Blocklists")
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(32.dp))

            val ringColor = if (running) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
            Box(
                modifier = Modifier
                    .size(180.dp)
                    .clip(CircleShape)
                    .background(ringColor.copy(alpha = 0.12f))
                    .clickable { onToggleProtection(!running) },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Shield,
                    contentDescription = null,
                    tint = ringColor,
                    modifier = Modifier.size(84.dp)
                )
            }

            Spacer(Modifier.height(20.dp))
            Text(
                text = if (running) "Protected" else "Not protected",
                style = MaterialTheme.typography.headlineLarge
            )
            Text(
                text = if (running) "Tap the shield to pause" else "Tap the shield to start",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )

            Spacer(Modifier.height(32.dp))

            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp)) {
                    StatRow("Ads & trackers blocked this session", blocked.toString())
                    Spacer(Modifier.height(12.dp))
                    StatRow("Domains in active blocklist", BlocklistManager.blockedCount().toString())
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "This filters DNS locally on your device — no browsing data leaves your phone except the DNS lookups themselves.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
            )
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
    }
}
