package com.steven.adblockerpro.data

/**
 * Default, popular blocklists — enabled out of the box so the app is useful
 * with zero setup. Users can add any other hosts-format URL from the
 * "Blocklists" screen (that covers "add your own like uBlock/AdGuard").
 */
data class BlocklistSource(
    val id: String,
    val name: String,
    val url: String,
    val enabledByDefault: Boolean
)

object BlocklistSources {
    val DEFAULTS = listOf(
        BlocklistSource(
            id = "adguard_base",
            name = "AdGuard Base Filter",
            url = "https://raw.githubusercontent.com/AdguardTeam/AdguardFilters/master/BaseFilter/sections/adservers.txt",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "easylist",
            name = "EasyList",
            url = "https://easylist.to/easylist/easylist.txt",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "easyprivacy",
            name = "EasyPrivacy (tracker blocking)",
            url = "https://easylist.to/easylist/easyprivacy.txt",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "stevenblackhosts",
            name = "StevenBlack Unified Hosts",
            url = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "oisd",
            name = "OISD Basic",
            url = "https://small.oisd.nl/domainswild",
            enabledByDefault = false
        ),
        BlocklistSource(
            id = "goodbyeads",
            name = "Goodbye Ads",
            url = "https://raw.githubusercontent.com/jerryn70/GoodbyeAds/master/Hosts/GoodbyeAds.txt",
            enabledByDefault = false
        )
    )
}
