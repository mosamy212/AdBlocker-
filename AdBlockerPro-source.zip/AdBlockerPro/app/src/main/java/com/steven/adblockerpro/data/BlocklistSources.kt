package com.steven.adblockerpro.data

/**
 * Default, popular blocklists — enabled out of the box so the app is useful
 * with zero setup. Users can add any other hosts-format URL from the
 * "Blocklists" screen (that covers "add your own like uBlock/AdGuard").
 */
data class BlocklistSource(
    val id: String,
    val name: String,
    val url: String,
    val enabledByDefault: Boolean,
    val isExceptionList: Boolean = false // true = "don't block these" rules (like uBlock's unbreak.txt), not a block source
)

object BlocklistSources {
    val DEFAULTS = listOf(
        BlocklistSource(
            id = "adguard_base",
            name = "AdGuard Base Filter",
            url = "https://raw.githubusercontent.com/AdguardTeam/AdguardFilters/master/BaseFilter/sections/adservers.txt",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "easylist",
            name = "EasyList",
            url = "https://easylist.to/easylist/easylist.txt",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "easyprivacy",
            name = "EasyPrivacy (tracker blocking)",
            url = "https://easylist.to/easylist/easyprivacy.txt",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "stevenblackhosts",
            name = "StevenBlack Unified Hosts",
            url = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "ublock_filters",
            name = "uBlock Origin Filters",
            url = "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/filters.txt",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "ublock_privacy",
            name = "uBlock Origin Privacy",
            url = "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/privacy.txt",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "ublock_badware",
            name = "uBlock Origin Badware Risks",
            url = "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/badware.txt",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "ublock_resource_abuse",
            name = "uBlock Origin Resource Abuse",
            url = "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/resource-abuse.txt",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "ublock_unbreak",
            name = "uBlock Origin Unbreak (allowlist — fixes sites broken by other filters)",
            url = "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/unbreak.txt",
            enabledByDefault = true,
            isExceptionList = true
        ),
        BlocklistSource(
            id = "peter_lowe",
            name = "Peter Lowe's Ad Server List",
            url = "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "oisd",
            name = "OISD Basic",
            url = "https://small.oisd.nl/domainswild",
            enabledByDefault = true
        ),
        BlocklistSource(
            id = "goodbyeads",
            name = "Goodbye Ads",
            url = "https://raw.githubusercontent.com/jerryn70/GoodbyeAds/master/Hosts/GoodbyeAds.txt",
            enabledByDefault = true
        )
    )
}
