package com.steven.adblockerpro.ui.theme

import androidx.compose.ui.graphics.Color

// Core brand color: a clean, modern teal/green that reads as "protected"
val ShieldGreen = Color(0xFF2FD576)
val ShieldGreenDark = Color(0xFF1FA85C)

val BackgroundLight = Color(0xFFF7F8FA)
val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundDark = Color(0xFF0E1116)
val SurfaceDark = Color(0xFF171B21)

val TextPrimaryLight = Color(0xFF14181F)
val TextPrimaryDark = Color(0xFFE8EAED)
val TextSecondaryLight = Color(0xFF5C6470)
val TextSecondaryDark = Color(0xFF9AA3AF)

val DangerRed = Color(0xFFE5484D)
