package com.steven.adblockerpro.vpn

import java.nio.ByteBuffer

/**
 * Builds a raw IPv4 + UDP packet to hand back to the TUN interface, with
 * source/destination swapped relative to the original query — i.e. this
 * makes our reply look like it came from wherever the app thought it was
 * asking (itself acting as the "DNS server" the phone configured).
 */
object IpV4Packet {

    fun buildUdpReply(
        sourceIp: ByteArray, sourcePort: Int,
        destIp: ByteArray, destPort: Int,
        payload: ByteArray
    ): ByteArray {
        val udpLength = 8 + payload.size
        val totalLength = 20 + udpLength
        val buffer = ByteBuffer.allocate(totalLength)

        // ---- IPv4 header (20 bytes, no options) ----
        buffer.put((0x45).toByte())      // version 4, IHL 5 (20 bytes)
        buffer.put(0x00.toByte())        // DSCP/ECN
        buffer.putShort(totalLength.toShort())
        buffer.putShort(0)                // identification
        buffer.putShort(0x4000.toShort()) // flags: Don't Fragment
        buffer.put(64.toByte())           // TTL
        buffer.put(17.toByte())           // protocol: UDP
        val checksumPos = buffer.position()
        buffer.putShort(0)                // header checksum placeholder
        buffer.put(sourceIp)
        buffer.put(destIp)

        val ipHeader = buffer.array().copyOfRange(0, 20)
        val ipChecksum = checksum(ipHeader)
        buffer.putShort(checksumPos, ipChecksum.toShort())

        // ---- UDP header (8 bytes) ----
        buffer.putShort(sourcePort.toShort())
        buffer.putShort(destPort.toShort())
        buffer.putShort(udpLength.toShort())
        val udpChecksumPos = buffer.position()
        buffer.putShort(0) // UDP checksum optional over IPv4 — 0 = unused, valid per RFC 768
        buffer.put(payload)

        return buffer.array()
    }

    private fun checksum(data: ByteArray): Int {
        var sum = 0
        var i = 0
        while (i < data.size) {
            val word = ((data[i].toInt() and 0xFF) shl 8) or
                (if (i + 1 < data.size) (data[i + 1].toInt() and 0xFF) else 0)
            sum += word
            i += 2
        }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }
}
