package com.steven.adblockerpro.data

/**
 * Plain-DNS (port 53) upstream resolvers.
 * We forward already-allowed queries here after our own on-device
 * blocklist check. Plain UDP is used instead of DoH/DoT to keep the
 * VPN service light on CPU/battery for older devices.
 */
data class DnsPreset(
    val id: String,
    val displayName: String,
    val primaryIp: String,
    val secondaryIp: String,
    val description: String,
    val supportsCustomId: Boolean = false
)

object DnsPresets {

    val NEXTDNS = DnsPreset(
        id = "nextdns",
        displayName = "NextDNS",
        // NextDNS's linked IP resolves per-account when a config ID is appended
        // to the hostname over DoH; for plain DNS we use their anycast IPs and
        // let the user enter their config ID, applied via the DoH fallback path.
        primaryIp = "45.90.28.0",
        secondaryIp = "45.90.30.0",
        description = "Custom filtering + analytics. Needs a free config ID from nextdns.io",
        supportsCustomId = true
    )

    val CLOUDFLARE = DnsPreset(
        id = "cloudflare",
        displayName = "Cloudflare",
        primaryIp = "1.1.1.1",
        secondaryIp = "1.0.0.1",
        description = "Fast, privacy-focused, no filtering of its own"
    )

    val QUAD9 = DnsPreset(
        id = "quad9",
        displayName = "Quad9",
        primaryIp = "9.9.9.9",
        secondaryIp = "149.112.112.112",
        description = "Blocks known malicious domains at the DNS level"
    )

    val ADGUARD_DNS = DnsPreset(
        id = "adguard",
        displayName = "AdGuard DNS",
        primaryIp = "94.140.14.14",
        secondaryIp = "94.140.15.15",
        description = "Ad & tracker blocking built into the resolver itself"
    )

    val GOOGLE = DnsPreset(
        id = "google",
        displayName = "Google DNS",
        primaryIp = "8.8.8.8",
        secondaryIp = "8.8.4.4",
        description = "No filtering — use only if others are blocked in your region"
    )

    val ALL = listOf(NEXTDNS, CLOUDFLARE, QUAD9, ADGUARD_DNS, GOOGLE)
}
