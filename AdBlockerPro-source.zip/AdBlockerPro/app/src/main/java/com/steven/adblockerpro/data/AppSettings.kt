package com.steven.adblockerpro.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

class AppSettings(private val context: Context) {

    private object Keys {
        val DNS_PRESET = stringPreferencesKey("dns_preset_id")
        val NEXTDNS_CONFIG_ID = stringPreferencesKey("nextdns_config_id")
        val ENABLED_LISTS = stringSetPreferencesKey("enabled_blocklists")
        val CUSTOM_LISTS = stringSetPreferencesKey("custom_blocklists") // stores "id|name|url"
        val MANUAL_BLOCKED_DOMAINS = stringSetPreferencesKey("manual_blocked_domains")
        val ALLOWED_DOMAINS = stringSetPreferencesKey("allowed_domains")
        val THEME_MODE = stringPreferencesKey("theme_mode") // "system" | "light" | "dark"
        val VIRUSTOTAL_API_KEY = stringPreferencesKey("virustotal_api_key")
        val TOTAL_BLOCKED = longPreferencesKey("total_blocked_lifetime")
        val TOTAL_DATA_SAVED_BYTES = longPreferencesKey("total_data_saved_bytes")
        val AUTO_START = booleanPreferencesKey("auto_start_on_boot")
        val WAS_PROTECTION_ON = booleanPreferencesKey("was_protection_on")
    }

    val dnsPresetId: Flow<String> = context.dataStore.data.map {
        it[Keys.DNS_PRESET] ?: DnsPresets.CLOUDFLARE.id
    }

    val nextDnsConfigId: Flow<String> = context.dataStore.data.map {
        it[Keys.NEXTDNS_CONFIG_ID] ?: ""
    }

    val enabledBlocklistIds: Flow<Set<String>> = context.dataStore.data.map {
        it[Keys.ENABLED_LISTS] ?: BlocklistSources.DEFAULTS.filter { s -> s.enabledByDefault }.map { s -> s.id }.toSet()
    }

    val customBlocklists: Flow<List<BlocklistSource>> = context.dataStore.data.map { prefs ->
        (prefs[Keys.CUSTOM_LISTS] ?: emptySet()).mapNotNull { entry ->
            val parts = entry.split("|", limit = 3)
            if (parts.size == 3) BlocklistSource(parts[0], parts[1], parts[2], enabledByDefault = false) else null
        }
    }

    val manualBlockedDomains: Flow<Set<String>> = context.dataStore.data.map {
        it[Keys.MANUAL_BLOCKED_DOMAINS] ?: emptySet()
    }

    val themeMode: Flow<String> = context.dataStore.data.map {
        it[Keys.THEME_MODE] ?: "system"
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode }
    }

    suspend fun addManualBlockedDomain(domain: String) {
        val clean = domain.trim().lowercase().removePrefix("http://").removePrefix("https://").substringBefore("/")
        if (clean.isEmpty()) return
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.MANUAL_BLOCKED_DOMAINS] ?: emptySet()
            prefs[Keys.MANUAL_BLOCKED_DOMAINS] = current + clean
        }
    }

    suspend fun removeManualBlockedDomain(domain: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.MANUAL_BLOCKED_DOMAINS] ?: emptySet()
            prefs[Keys.MANUAL_BLOCKED_DOMAINS] = current - domain
        }
    }

    val allowedDomains: Flow<Set<String>> = context.dataStore.data.map {
        it[Keys.ALLOWED_DOMAINS] ?: emptySet()
    }

    suspend fun addAllowedDomain(domain: String) {
        val clean = domain.trim().lowercase().removePrefix("http://").removePrefix("https://").substringBefore("/")
        if (clean.isEmpty()) return
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.ALLOWED_DOMAINS] ?: emptySet()
            prefs[Keys.ALLOWED_DOMAINS] = current + clean
        }
    }

    suspend fun removeAllowedDomain(domain: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.ALLOWED_DOMAINS] ?: emptySet()
            prefs[Keys.ALLOWED_DOMAINS] = current - domain
        }
    }

    val virusTotalApiKey: Flow<String> = context.dataStore.data.map {
        it[Keys.VIRUSTOTAL_API_KEY] ?: ""
    }

    suspend fun setVirusTotalApiKey(key: String) {
        context.dataStore.edit { it[Keys.VIRUSTOTAL_API_KEY] = key.trim() }
    }

    suspend fun setDnsPreset(id: String) {
        context.dataStore.edit { it[Keys.DNS_PRESET] = id }
    }

    suspend fun setNextDnsConfigId(id: String) {
        context.dataStore.edit { it[Keys.NEXTDNS_CONFIG_ID] = id }
    }

    suspend fun setEnabledBlocklists(ids: Set<String>) {
        context.dataStore.edit { it[Keys.ENABLED_LISTS] = ids }
    }

    suspend fun addCustomBlocklist(name: String, url: String) {
        val id = "custom_${System.currentTimeMillis()}"
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.CUSTOM_LISTS] ?: emptySet()
            prefs[Keys.CUSTOM_LISTS] = current + "$id|$name|$url"
        }
    }

    suspend fun removeCustomBlocklist(id: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.CUSTOM_LISTS] ?: emptySet()
            prefs[Keys.CUSTOM_LISTS] = current.filterNot { it.startsWith("$id|") }.toSet()
        }
    }

    // --- Lifetime stats (survive app restarts, unlike the in-session counter on Home) ---

    val totalBlockedLifetime: Flow<Long> = context.dataStore.data.map { it[Keys.TOTAL_BLOCKED] ?: 0L }
    val totalDataSavedBytes: Flow<Long> = context.dataStore.data.map { it[Keys.TOTAL_DATA_SAVED_BYTES] ?: 0L }

    /** Adds to the lifetime totals. Called periodically by the VPN service, not per-packet, to avoid excessive disk writes. */
    suspend fun addToLifetimeStats(blockedDelta: Long, dataSavedDelta: Long) {
        if (blockedDelta == 0L && dataSavedDelta == 0L) return
        context.dataStore.edit { prefs ->
            prefs[Keys.TOTAL_BLOCKED] = (prefs[Keys.TOTAL_BLOCKED] ?: 0L) + blockedDelta
            prefs[Keys.TOTAL_DATA_SAVED_BYTES] = (prefs[Keys.TOTAL_DATA_SAVED_BYTES] ?: 0L) + dataSavedDelta
        }
    }

    // --- Auto-start on boot ---

    val autoStartEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTO_START] ?: true }

    suspend fun setAutoStartEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_START] = enabled }
    }

    val wasProtectionOn: Flow<Boolean> = context.dataStore.data.map { it[Keys.WAS_PROTECTION_ON] ?: false }

    suspend fun setWasProtectionOn(on: Boolean) {
        context.dataStore.edit { it[Keys.WAS_PROTECTION_ON] = on }
    }
}
