package com.steven.adblockerpro.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

class AppSettings(private val context: Context) {

    private object Keys {
        val DNS_PRESET = stringPreferencesKey("dns_preset_id")
        val NEXTDNS_CONFIG_ID = stringPreferencesKey("nextdns_config_id")
        val ENABLED_LISTS = stringSetPreferencesKey("enabled_blocklists")
        val CUSTOM_LISTS = stringSetPreferencesKey("custom_blocklists") // stores "id|name|url"
    }

    val dnsPresetId: Flow<String> = context.dataStore.data.map {
        it[Keys.DNS_PRESET] ?: DnsPresets.CLOUDFLARE.id
    }

    val nextDnsConfigId: Flow<String> = context.dataStore.data.map {
        it[Keys.NEXTDNS_CONFIG_ID] ?: ""
    }

    val enabledBlocklistIds: Flow<Set<String>> = context.dataStore.data.map {
        it[Keys.ENABLED_LISTS] ?: BlocklistSources.DEFAULTS.filter { s -> s.enabledByDefault }.map { s -> s.id }.toSet()
    }

    val customBlocklists: Flow<List<BlocklistSource>> = context.dataStore.data.map { prefs ->
        (prefs[Keys.CUSTOM_LISTS] ?: emptySet()).mapNotNull { entry ->
            val parts = entry.split("|", limit = 3)
            if (parts.size == 3) BlocklistSource(parts[0], parts[1], parts[2], enabledByDefault = false) else null
        }
    }

    suspend fun setDnsPreset(id: String) {
        context.dataStore.edit { it[Keys.DNS_PRESET] = id }
    }

    suspend fun setNextDnsConfigId(id: String) {
        context.dataStore.edit { it[Keys.NEXTDNS_CONFIG_ID] = id }
    }

    suspend fun setEnabledBlocklists(ids: Set<String>) {
        context.dataStore.edit { it[Keys.ENABLED_LISTS] = ids }
    }

    suspend fun addCustomBlocklist(name: String, url: String) {
        val id = "custom_${System.currentTimeMillis()}"
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.CUSTOM_LISTS] ?: emptySet()
            prefs[Keys.CUSTOM_LISTS] = current + "$id|$name|$url"
        }
    }

    suspend fun removeCustomBlocklist(id: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.CUSTOM_LISTS] ?: emptySet()
            prefs[Keys.CUSTOM_LISTS] = current.filterNot { it.startsWith("$id|") }.toSet()
        }
    }
}
