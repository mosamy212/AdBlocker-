package com.steven.adblockerpro.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.steven.adblockerpro.data.AppSettings
import com.steven.adblockerpro.data.LogEntry
import com.steven.adblockerpro.data.ActivityLog
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivityLogScreen(settings: AppSettings, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var entries by remember { mutableStateOf(ActivityLog.recent()) }

    LaunchedEffect(Unit) {
        while (true) {
            entries = ActivityLog.recent()
            delay(2000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Activity") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(
                    "No activity yet — turn protection on and browse a bit, requests will show up here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    modifier = Modifier.padding(32.dp)
                )
            }
        } else {
            LazyColumn(modifier = Modifier.padding(padding).padding(horizontal = 16.dp)) {
                items(entries) { entry ->
                    LogRow(
                        entry = entry,
                        onAllow = { scope.launch { settings.addAllowedDomain(entry.domain) } },
                        onBlock = { scope.launch { settings.addManualBlockedDomain(entry.domain) } }
                    )
                }
                item { Spacer(Modifier.height(40.dp)) }
            }
        }
    }
}

@Composable
private fun LogRow(entry: LogEntry, onAllow: () -> Unit, onBlock: () -> Unit) {
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    var expanded by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxWidth().padding(vertical = 6.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().clickableToggle { expanded = !expanded },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(entry.domain, style = MaterialTheme.typography.bodyMedium)
                Text(timeFmt.format(Date(entry.timestampMillis)), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            }
            AssistChip(
                onClick = { expanded = !expanded },
                label = { Text(if (entry.blocked) "Blocked" else "Allowed") },
                colors = AssistChipDefaults.assistChipColors(
                    containerColor = if (entry.blocked) MaterialTheme.colorScheme.errorContainer
                    else Color.Transparent
                )
            )
        }
        if (expanded) {
            Row(Modifier.padding(top = 4.dp)) {
                TextButton(onClick = onAllow) { Text("Add to allowlist") }
                TextButton(onClick = onBlock) { Text("Add to denylist") }
            }
        }
        HorizontalDivider(Modifier.padding(top = 6.dp))
    }
}

// Small helper so the row is clickable without importing foundation.clickable at file scope twice
private fun Modifier.clickableToggle(onToggle: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable { onToggle() })
