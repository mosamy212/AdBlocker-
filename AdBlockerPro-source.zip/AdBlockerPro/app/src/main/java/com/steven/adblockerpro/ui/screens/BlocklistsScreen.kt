package com.steven.adblockerpro.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.steven.adblockerpro.data.AppSettings
import com.steven.adblockerpro.data.BlocklistSource
import com.steven.adblockerpro.data.BlocklistSources
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlocklistsScreen(settings: AppSettings, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val enabledIds by settings.enabledBlocklistIds.collectAsState(initial = emptySet())
    val customLists by settings.customBlocklists.collectAsState(initial = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Blocklists") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add custom list")
            }
        }
    ) { padding ->
        LazyColumnLists(
            padding = padding,
            defaults = BlocklistSources.DEFAULTS,
            custom = customLists,
            enabledIds = enabledIds,
            onToggle = { id, isOn ->
                scope.launch {
                    val updated = if (isOn) enabledIds + id else enabledIds - id
                    settings.setEnabledBlocklists(updated)
                }
            },
            onRemoveCustom = { id -> scope.launch { settings.removeCustomBlocklist(id) } }
        )
    }

    if (showAddDialog) {
        AddBlocklistDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { name, url ->
                scope.launch { settings.addCustomBlocklist(name, url) }
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun LazyColumnLists(
    padding: PaddingValues,
    defaults: List<BlocklistSource>,
    custom: List<BlocklistSource>,
    enabledIds: Set<String>,
    onToggle: (String, Boolean) -> Unit,
    onRemoveCustom: (String) -> Unit
) {
    androidx.compose.foundation.lazy.LazyColumn(
        modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        item {
            Text(
                "Popular lists — same sources AdGuard / uBlock Origin use",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }
        items(defaults) { source ->
            BlocklistRow(
                name = source.name,
                enabled = enabledIds.contains(source.id),
                onToggle = { onToggle(source.id, it) }
            )
        }

        if (custom.isNotEmpty()) {
            item {
                Text(
                    "Your custom lists",
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
            items(custom) { source ->
                BlocklistRow(
                    name = source.name,
                    enabled = enabledIds.contains(source.id),
                    onToggle = { onToggle(source.id, it) },
                    onRemove = { onRemoveCustom(source.id) }
                )
            }
        }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

@Composable
private fun BlocklistRow(
    name: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit,
    onRemove: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(name, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        if (onRemove != null) {
            TextButton(onClick = onRemove) { Text("Remove") }
        }
        Switch(checked = enabled, onCheckedChange = onToggle)
    }
    HorizontalDivider()
}

@Composable
private fun AddBlocklistDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a custom blocklist") },
        text = {
            Column {
                Text(
                    "Paste any hosts-file or AdBlock-format URL — the same kind AdGuard/uBlock Origin subscriptions use.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("URL") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (name.isNotBlank() && url.isNotBlank()) onAdd(name, url) },
                enabled = name.isNotBlank() && url.isNotBlank()
            ) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
