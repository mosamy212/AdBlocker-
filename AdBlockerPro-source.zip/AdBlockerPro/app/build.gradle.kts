plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.steven.adblockerpro"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.steven.adblockerpro"
        // API 28 = Android 9 "Pie" — keeps it usable on old phones
        minSdk = 28
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources.excludes.add("/META-INF/{AL2.0,LGPL2.1}")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")

    // Compose BOM keeps all Compose versions in sync
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // Lightweight persistence for blocklists / settings — no heavy Room DB needed
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // Small, fast HTTP client for downloading blocklists
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Background blocklist refresh without waking the phone unnecessarily
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
