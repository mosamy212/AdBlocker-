# AdBlocker Pro

A local, VPN-based ad/tracker blocker for Android — no root needed, works on Android 9 (API 28) and up.

## What it does
- Filters DNS on-device using a merged, deduped blocklist (AdGuard Base, EasyList, EasyPrivacy, StevenBlack Hosts enabled by default; OISD and GoodbyeAds available to enable; add any hosts-file or AdBlock-format URL yourself).
- Sends anything not blocked to a resolver you pick: NextDNS, Cloudflare, Quad9, AdGuard DNS, or Google DNS.
- Only DNS traffic is intercepted (`addRoute("10.111.222.2", 32)`) — your actual browsing/streaming data is never routed through the tunnel, so it does **not** add to your data usage; if anything it reduces it since blocked ad requests never happen.
- Material 3 UI with automatic light/dark (night) mode, and dynamic color on Android 12+.

## How to build (no computer needed — GitHub builds it for you)

1. Make a free account at github.com (works fine from your phone browser or the GitHub app).
2. Create a **new repository** (name it anything, e.g. `adblocker-pro`).
3. Upload every file from this unzipped folder into that repo — on the repo page, tap **Add file → Upload files**, and drag/select everything (keep the folder structure).
4. Commit to the `main` branch. This alone triggers the build automatically (there's a `.github/workflows/build.yml` already included).
5. Go to the **Actions** tab in your repo → click the running/finished workflow → scroll to **Artifacts** → download `AdBlockerPro-debug-apk`. It's a `.zip` containing `app-debug.apk`.
6. On your phone: unzip it (any file manager app can do this), tap the `.apk` file, allow "install unknown apps" if prompted, and install.

That's the whole process — no computer, no Android Studio required. If you ever want to make changes, edit files right in GitHub's web editor and it rebuilds automatically on every commit.

## How to build (with a computer — Android Studio)
1. Open this folder in Android Studio (Koala or newer).
2. Let Gradle sync — it will pull the dependencies listed in `app/build.gradle.kts`.
3. Run on a device or emulator with API 28+.
4. First run will ask for VPN permission (standard Android system dialog) — this is required for any no-root ad blocker.

You'll need to supply your own launcher icon — this is now already included as a simple green shield adaptive icon, so no extra step is required.

## Known limitations / next steps (being upfront about these)
- **NextDNS config ID**: plain DNS (port 53, what this app uses for speed/low battery cost) doesn't carry your config ID the way DNS-over-HTTPS does. Right now, picking NextDNS routes to their anycast IPs, which only becomes *your* personalized config if you link your public IP in the NextDNS dashboard (nextdns.io → Settings → Linked IP) — entering the config ID in-app doesn't do anything yet. Full support means adding DNS-over-HTTPS (DoH), which is a bigger addition (see below).
- **IPv4 only**: the packet parser doesn't handle IPv6 DNS traffic yet. On IPv6-only networks, some queries would fall through unfiltered.
- **YouTube in-app video ads**: as discussed, these are served from the same domains as video content and can't be blocked at the DNS level — no ad blocker can fully solve this on Android without a modified YouTube client (e.g. ReVanced).
- **Single-threaded packet loop**: fine for typical phone usage; under very heavy simultaneous connections a multi-threaded reader would keep it snappier. Left simple on purpose for lower CPU/battery draw on old phones per your "light on old phones" requirement.

## Project structure
```
app/src/main/java/com/steven/adblockerpro/
  MainActivity.kt              — nav host, VPN permission flow
  vpn/AdBlockVpnService.kt     — the core packet-intercepting VpnService
  vpn/DnsMessage.kt            — parse query name / build NXDOMAIN reply
  vpn/IpV4Packet.kt            — raw IPv4/UDP packet construction
  data/BlocklistManager.kt     — downloads + parses + merges blocklists
  data/BlocklistSources.kt     — default list of popular blocklists
  data/DnsPresets.kt           — NextDNS/Cloudflare/Quad9/AdGuard DNS/Google
  data/AppSettings.kt          — DataStore-backed user settings
  ui/screens/                  — Home, Blocklists, Settings (Compose)
  ui/theme/                    — Material 3 theme, light/dark mode
```
